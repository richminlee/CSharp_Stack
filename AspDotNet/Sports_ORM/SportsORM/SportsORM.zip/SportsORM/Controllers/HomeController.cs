﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.WomensLeagues = context.Leagues
                .Where(l => l.Name.Contains("Womens"));
            ViewBag.HockeyLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Hockey"));
            ViewBag.NotFootballLeagues = context.Leagues
                .Where(l => l.Sport != "Football");
            ViewBag.ConferenceLeagues = context.Leagues
                .Where(l => l.Name.Contains("Conference"));
            ViewBag.AtlanticLeagues = context.Leagues
                .Where(l => l.Name.Contains("Atlantic"));
            ViewBag.DallasTeams = context.Teams
                .Where(l => l.Location.Contains("Dallas"));
            ViewBag.RaptorTeams = context.Teams
                .Where(l => l.TeamName.Contains("Raptor"));
            ViewBag.CityTeams = context.Teams
                .Where(l => l.Location.Contains("City"));
            ViewBag.TTeams = context.Teams
                .Where(l => l.TeamName.Contains("T"));
            ViewBag.OrderedTeams = context.Teams
                .OrderBy(l => l.Location);
            ViewBag.ReverseTeams = context.Teams
                .OrderByDescending(l => l.TeamName);
            ViewBag.CooperPlayers = context.Players
                .Where(l => l.LastName.Contains("Cooper"));
            ViewBag.JoshuaPlayers = context.Players
                .Where(l => l.FirstName.Contains("Joshua"));
            var CooperPlayers = context.Players
                .Where(l => l.LastName.Contains("Cooper"));
            var JoshuaPlayers = context.Players
                .Where(l => l.FirstName.Contains("Joshua"));
            ViewBag.NoJoshuaCooper = CooperPlayers
                .Except(JoshuaPlayers);
            ViewBag.AWPlayers = context.Players
                .Where(l => l.FirstName.Contains("Alexander") || l.FirstName.Contains("Wyatt"));
            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            ViewBag.ReverseTeams = context.Teams
                .OrderByDescending(l => l.TeamName);
            ViewBag.CooperPlayers = context.Players
                .Where(l => l.LastName.Contains("Cooper"));
            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}